#!/bin/sh
exec java -jar CheckJDBC.jar -f $1
